#Help in R
help.start()                        

# general help displayed in a web browser
help("c")

# help on function "c"
?c

# help on function "c"
help.search("c")  

# search for instances of the string "c"
??c    

# search for instances of the string "c"
apropos("c", mode="function") 


#Get working Example of the command
example("c")
sink(example.txt)

#Other Usefull commands
R.version.string

#features which have been compiled into this build of R.
capabilities()

#Display the home directory
R.home()

#Get the working directory
getwd()

#set new working directory
setwd("D:/Notes/Analytics/R/Demos")

#display the last 'n' commands (default = 25)
history(4)

#execute commands in the filename.R script
source("filename.R") 

#divert R output to an external file
sink("out.txt") 

#stop sink-ing (results return to console)
sink()
