# Defining Variables and Assigning Values
x <- 100
x

#------------ String Values ---------------------
myString <- "Hello, World!"
print(myString)

#The quotes at the beginning and end of a string should be both double quotes or both single quote. 
a <- 'Start and end with single quote'
print(a)

b <- "Start and end with double quotes"
print(b)

c <- "single quote ' in between double quotes"
print(c)

d <- 'Double quotes " in between single quote'
print(d)

#Internally R stores every string with in double quotes 
#even when you create them with single quote.

#------------------------------------------------------------------
#The variables can be assigned values using leftward, rightward and equal to operator.
#The values of the variables can be printed using print() or cat() function. 
#The cat() function combines multiple items into a continuous print output.

# Assignment using equal operator.
var.1 = c(0,1,2,3) 
print(var.1)
class(var.1)

var.11=c('Syntel',2016,1L)
print(var.11)

# Assignment using leftward operator.
var.2 <- c("learn","R")   

# Assignment using rightward operator.   
c(TRUE,1) -> var.3           

print(var.1,var.11)
cat ("var.1 is ", var.1 ,"\n")
cat ("var.2 is ", var.2 ,"\n")
cat ("var.3 is ", var.3 ,"\n")

LETTERS
pi
pi=10
pi

#Get the list of reserved word
?reserved
help(reserved)
example(c)

x=numeric(10)
print(x)

#Coercing into integer
y=as.integer(3.57)
print(y)
y=as.integer("34Bell")
class(y)
y=as.integer(-34.67)

#Complex Values
val=3+5i
val
class(val)
typeof(val)
is.character(val)




#Data Objects:
  #Simple Classes: Logical,Numeric,Integer,character,Raw and Complex
  #Complex Classes: Vectors,List,Matrices,Arrays,Factors,Data Frames

#The variables are assigned with R-Objects and the data type of the R-object 
#becomes the data type of the variable.

#Logical Variables
v <- TRUE 
V <- T
print(V)
#R is case-sensitive
v1 = "true"

print(class(V))
print(class(v1))

#Numeric Values
v <- 23.5
print(class(v))

#Integer Values
v <- 2L
print(class(v))

#Complex Values
v <- 2+5i
print(class(v))
print(v)

#Character Values
v <- "TRUE"
print(class(v))


#Raw Values
v <- charToRaw("Hello")
print(class(v))
print(v)
# Converting the raw value back to string
str <- rawToChar(v)
print(str)

#-----------------------------Listing out the Variables-----------------------------
#To know all the variables currently available in the workspace we use the ls() function. 
#Also the ls() function can use patterns to match the variable names.

print(ls())

#The ls() function can use patterns to match the variable names.
.hidden_value="hideit"
ls(all.names = T)
# List the variables starting with the pattern "var".
print(ls(pattern="var",all.names = TRUE))   

#The variables starting with dot(.) are hidden,
#they can be listed using "all.names=TRUE" argument to ls() function.

print(ls(all.name=TRUE))


#------------------------------Deleting Variables-----------------------------------
#Variables can be deleted by using the rm() function. Below we delete the variable var.3. 
rm(var.1)
print(var.1)

#All the variables can be deleted by using the rm() and ls() function together.

rm(list=ls(all.name=TRUE))
print(ls())

#----------------------------------ARRAYS---------------------------------

#Create an Array from a range
x <- 1:12
x

#Create an Array using the row and column
dim(x) <- c(3, 4)
x

#Another Example: The variable has to be defined before the dimension is set
dim(y) <- c(2, 5)
y <- 1:10
y

#Print number of rows
nrow(x)

#Print number of columns
ncol(x)

#Create an Array from a Character range
x <- "A":"L"
x

#Array of String
a<-array(c('red','green',"yellow","white"),dim=c(2,2))
print(a)
print(class(a))

#----------------------------------VECTORS-------------------------------------------

# Create a vector.
#Simple Vectors
x=c(1:7,3.56)
length(x)
class(x)
#First Element
x[1]

#First and 3rd element
x[c(1,3)]

#Show all except the First and 3rd element
x[c(-1,-3)]

#Delete the 3rd element
x[3]=NA
x=NULL
x
rm(x[3])

x=c(1,4.5,TRUE)
class(x)

#Named Vector
v=c(1,2,3,4,5,6,7)
names(v)=c("Mon","Tue","Wed","Thr","Fri","Sat")
v["Wed"]
v[5]
v


apple <- c('red','green',"yellow","white")
print(apple)
dim(apple)=c(2,2)
print(apple)
print(class(apple))

# Get the class of the vector.
print(class(apple))

# Creating a sequence from 5 to 13.
v <- 5:13
print(v)
dim(v)=c(3,3)
print(v)
print(class(v))

# Creating a sequence from 6.6 to 12.6.
v <- 6.6:12.6
print(v)

# If the final element specified does not belong to the sequence then it is discarded.
v <- 3.1:3.8
print(v)
print(class(v))

# Create vector with elements from 5 to 9 incrementing by 0.4.
print(seq(5, 9, by=0.4))
print(seq(5, 9, by=0.3))
print(seq(5.1,length.out = 5))

#----Accessing Vector Elements

# Accessing vector elements using position.
t <- c("Sun","Mon","Tue","Wed","Thurs","Fri","Sat")
u <- t[c(2,3,6)]
print(u)

# Accessing vector elements using logical indexing.
v <- t[c(TRUE,FALSE,FALSE,FALSE,FALSE,TRUE,FALSE)]
print(v)

# Accessing vector elements using negative indexing.
x <- t[c(-2,-5)]
print(x)

# Accessing vector elements using 0/1 indexing.
t <- c("Sun","Mon","Tue","Wed","Thurs","Fri","Sat")
y <- t[c(0,0,0,0,0,0,1)]
print(y)
print(t[1])

#---- Vector Arithmetic
# Create two vectors.
v1 <- c(3,8,4,5,0,11)
v2 <- c(4,11,0,8,1,2)

# Vector addition.
add.result <- v1+v2
print(add.result)

# Vector substraction.
sub.result <- v1-v2
print(sub.result)

# Vector multiplication.
multi.result <- v1*v2
print(multi.result)

# Vector division.
divi.result <- v1/v2
print(divi.result)

#Vector Addition
v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v+t)

#Vector Subtraction
v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v-t)

#Remainders
v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v%%t)

#Logical Operators
v <- c(2,5.5,6,9)
t <- c(8,2.5,14,9)
print(v>t)
print(v<=t)
print(v==t)

#AND Operator
v <- c(3,1,TRUE,2+3i)
t <- c(4,1,FALSE,2+3i)
print(v&t)

#AND Operator - different types
v <- c(3.5,5+6i,TRUE,2+3i)
t <- c(4,1,FALSE,2+3i)
print(v&t)

#Takes first element of both the 
#vectors and gives the TRUE only if both are TRUE.
v <- c(3,0,TRUE,2+2i)
class(v)
t <- c(1,3,TRUE,2+3i)
print(v&t)
print(v&&t)

#NOT Operator
v <- c(3,0,TRUE,2+2i)
print(!v)

#Heterogeneous Data
v <- c(3L,0,TRUE,2+2i)
print(v)
print(class(v))

v <- c(3,'Apple',TRUE,2+2i)
print(v)
print(class(v))
print(class(v[3]))

#-------Vector Element Recycling

#If we apply arithmetic operations to two vectors of unequal length, 
#then the elements of the shorter vector are recycled to complete the operations.

v1 <- c(3,8,4,5,0,11,12,9)
v2 <- c(4,11)
# V2 becomes c(4,11,4,11,4,11)

add.result <- v1+v2
print(add.result)

sub.result <- v1-v2
print(sub.result)

#--------Vector element sorting
#Elements in a vector can be sorted using sort() function.

v <- c(3,8,4,5,0,11, -9, 304)

# Sort the elements of the vector.
sort.result <- sort(v)
print(sort.result)

# Sort the elements in the reverse order.
revsort.result <- sort(v, decreasing = TRUE)
print(revsort.result)

# Sorting character vectors.
v <- c("Red","Blue","yellow","violet")
sort.result <- sort(v)
print(sort.result)

# Sorting character vectors in reverse order.
revsort.result <- sort(v, decreasing = TRUE)
print(revsort.result)
#----------------------------------LISTS-------------------------------------------
#A list is a R-object which can contain many different types of elements inside it 
#like vectors, functions and even another list inside it.

# Create a list.
list1 <- list(c(2,5,3),21.3,sin)
# Print the list.
print(list1)

# Create a list containing strings, numbers, vectors and a logical values.
list_data <- list("Red", "Green", c(21,32,11), TRUE, 51.23, 119.1)
print(list_data)

#----------Accessing List Elements
#Elements of the list can be accessed by the index of the element in the list. 
#In case of named lists it can also be accessed using the names.

# Create a list containing a vector, a matrix and a list.
list_data <- list(c("Jan","Feb","Mar"), matrix(c(3,9,5,1,-2,8), nrow=2), list("green",12.3))
# Give names to the elements in the list.
list_data
names(list_data) <- c("FirstQuarter", "A_Matrix", "A Inner list")

# Access the first element of the list.
print(list_data[2])
# Access the thrid element. As it is also a list, all its elements will be printed.
print(list_data[3])

# Access the list element using the name of the element.
print(list_data$A_Matrix)
print(list_data$FirstQuarter[1])

#-------Manipulating List Elements
#We can add, delete and update list elements as shown below. 
#We can add and delete elements only at the end of a list. 
#But we can update any element.

# Create a list containing a vector, a matrix and a list.
list_data <- list(c("Jan","Feb","Mar"), matrix(c(3,9,5,1,-2,8), nrow=2), list("green",12.3))

list_data
class(list_data)

vect1=unlist(list_data)
vect1

class(vect1)

list_data
# Give names to the elements in the list.
names(list_data) <- c("1st Quarter", "A_Matrix", "A Inner list")


# Add element at the end of the list.
list_data[4] <- "New element"
print(list_data)

print(list_data)
# Remove the last element.
list_data[4] <- NULL

# Print the 4th Element.
print(list_data[4])

# Update the 3rd Element.
list_data[3] <- "updated element"
print(list_data[3])

#---------Merging Lists
#You can merge many lists into one list by placing all the 
#lists inside one list() 
#function.

# Create two lists.
list1 <- list(1,2,3)
list2 <- list("Sun","Mon","Tue")

# Merge the two lists.
merged.list <- c(list1,list2)

print(unlist(merged.list))

# Print the merged list.
print(merged.list)

#---------Converting List to Vector
#A list can be converted to a vector so that the elements of the vector
#can be used 
#for further manipulation. All the arithmetic operations on vectors can 
#be applied 
#after the list is converted into vectors. To do this conversion we use 
#the unlist() function. It takes the list as input and produces a vector.

# Create lists.
list1 <- list(1:5)
print(list1)

list2 <-list(10:14)
print(list2)

# Convert the lists to vectors.
v1 <- unlist(list1)
v2 <- unlist(list2)

print(v1)
print(v2)

class(v1)

print(typeof(v1))
#-- for matrix
mlist<- matrix(c(1,2,3,4,5,6),nrow = 3)
vmat=unlist(mlist)
vmat
class(vmat)


# Now add the vectors
result <- v1+v2
print(result)

#-------------------------------MATRICES--------------------------------------------
#A matrix is a two-dimensional rectangular data set. 
#It can be created using a vector input to the matrix function.

M = matrix( c('a','a','b','c','b'), nrow=2,ncol=3,byrow = TRUE)
print(M)

?matrix()

M = matrix( c('a','a','b','c','b'), nrow=3,ncol=3,byrow=FALSE)
#M -> 'a','a','b','c','b','a','a','b','c'
print(M)

# Elements are arranged sequentially by row.
M <- matrix(c(3:14), nrow=4, byrow=TRUE)
print(M)

# Elements are arranged sequentially by column.
N <- matrix(c(3:14), nrow=4)
print(N)

# Define the column and row names.
rownames = c("row1", "row2", "row3", "row4")
colnames = c("col1", "col2", "col3")

P <- matrix(c(3:14), nrow=4, byrow=TRUE, dimnames=list(rownames, colnames))
print(P)

#Reading matrix data from a file
setwd("D:/Notes/Analytics/R/Demos")
p=matrix(scan('matrix.dat'),nrow=3,byrow=FALSE)
print(p)

#-----------Accessing Elements of the Matrix
# Define the column and row names.
rownames = c("row1", "row2", "row3", "row4")
colnames = c("col1", "col2", "col3")

# Create the matrix.
P <- matrix(c(3:14), nrow=4, byrow=TRUE, dimnames=list(rownames, colnames))
P
# Access the element at 3rd column and 1st row.
print(P[1,3])

# Access the element at 2nd column and 4th row.
print(P[4,2])

# Access only the  2nd row.
print(P[2,])

# Access only the 3rd column.
print(P[,3])

#-------Matrix Addition & Subtraction
# Create two 2x3 matrices.
matrix1 <- matrix(c(3, 9, -1, 4, 2, 6), nrow=2)
print(matrix1)

matrix2 <- matrix(c(5, 2, 0, 9, 3, 4), nrow=2)
print(matrix2)

# Add the matrices.
result <- matrix1 + matrix2
cat("Result of addition","\n")
print(result)

# Subtract the matrices
result <- matrix1 - matrix2
cat("Result of subtraction","\n")
print(result)

# Multiply the matrices
result <- matrix1 * matrix2
cat("Result of Multiplication","\n")
print(result)

#-----------------------------ARRAYS-----------------------------------------------
#While matrices are confined to two dimensions, 
#arrays can be of any number 
#of dimensions. The array function 
#takes a dim attribute which creates the 
#required number of dimension.

# Create an array.
a <- array(c('green','yellow'),dim=c(3,3,3))
print(a)


# Create two vectors of different lengths.
vector1 <- c(5,9)
vector2 <- c(10,11,12,13,14,15)

# Take these vectors as input to the array.
result <- array(c(vector1,vector2),dim=c(3,3,2))
print(result)

#---------Naming Columns and Rows
#We can give names to the rows, columns and matrices in the array by using 
#the dimnames parameter.

# Create two vectors of different lengths.
vector1 <- c(5,9,3)
vector2 <- c(10,11,12,13,14,15)
column.names <- c("COL1","COL2","COL3")
row.names <- c("ROW1","ROW2","ROW3")
matrix.names <- c("Matrix1","Matrix2")

# Take these vectors as input to the array.
result <- array(c(vector1,vector2),dim=c(3,3,2),dimnames = list(row.names,column.names,matrix.names))
print(result)

#--------Accessing Array Elements
# Create two vectors of different lengths.
vector1 <- c(5,9)
vector2 <- c(10,11,12,13,14,15)
column.names <- c("COL1","COL2","COL3")
row.names <- c("ROW1","ROW2","ROW3")
matrix.names <- c("Matrix1","Matrix2")

# Take these vectors as input to the array.
result <- array(c(vector1,vector2),dim=c(3,3,2),dimnames = list(row.names,column.names,matrix.names))

result

# Print the third row of the second matrix of the array.
print(result[3,,2])

# Print the element in the 1st row and 3rd column of the 1st matrix.
print(result[1,3,1])

# Print the 2nd Matrix.
print(result[,,2])

#-------------Manipulating Array Elements
# Create two vectors of different lengths.
vector1 <- c(5,9,3)
vector2 <- c(10,11,12,13,14,15)

# Take these vectors as input to the array.
array1 <- array(c(vector1,vector2),dim=c(3,3,2))

# Create two vectors of different lengths.
vector3 <- c(9,1,0)
vector4 <- c(6,0,11,3,14,1,2,6,9)
array2 <- array(c(vector1,vector2),dim=c(3,3,2))

# create matrices from these arrays.
matrix1 <- array1[,,2]
matrix2 <- array2[,,2]
matrix1
matrix2
# Add the matrices.
result <- matrix1+matrix2
print(result)


#Matrices can be transposed by the t() function.
t(result)

#-----------Calculations Across Array Elements
#We can do calculations across the elements in an 
#array using the apply() function.

# Create two vectors of different lengths.
vector1 <- c(5,9,3)
vector2 <- c(10,11,12,13,14,15)

# Take these vectors as input to the array.
new.array <- array(c(vector1,vector2),dim=c(3,3,2))
print(new.array)

# Use apply to calculate the sum of the rows across all the matrices.
result <- apply(new.array, c(1), sum)
print(result)
 ?apply()


#---------------------------FACTORS-----------------------------------------------
#Factors are the r-objects which are created using a vector.
#It stores the vector along with the distinct values of the elements
#in the vector as labels. The labels are always character 
#irrespective of whether it is numeric or character or boolean etc 
#in the input vector. #They are useful in statistical modeling.

#Factors are created using the factor() function.
#The nlevels functions gives the count of levels.

# Create a vector.
apple_colors <- c('green','red','yellow','red','red','red','green')

# Create a factor object.
factor_apple <- factor(apple_colors)

# Print the factor.
print(factor_apple)
print(nlevels(factor_apple))

#Factors are created using the factor() function by taking a vector as input.
# Create a vector as input.
data <- c("East","West","East","North","North","East","West","West","West","East","North")
print(data)
print(is.factor(data))

# Apply the factor function.
factor_data <- factor(data)
print(factor_data)
print(is.factor(factor_data))

#---------Changing the order of Levels
#The order of the levels in a factor can be changed by applying 
#the factor #function again with new order of the levels.

data <- c("East",10,20,20,10,"West","East","North","North","East","West","West","West","East","North")
# Create the factors
factor_data <- factor(data)
print(factor_data)
print(class(factor_data))
print(length(data))


# Apply the factor function with required order of the level.
new_order_data <- factor(factor_data,levels = c("East","West","North"))
print(new_order_data)

#------------Generating Factor Levels------------------------
#We can generate factor levels by using the gl() function. 
#It takes two integers as input which indicates how many levels and 
#how many times each level.

v <- gl(3, 4, labels = c("Tampa", "Seattle","Boston"))
print(v)

#Creating a matrix out of the factor
my_matrix=matrix(v,nrow = 3,byrow = TRUE)
print(my_matrix)

#-------------------------DATA FRAMES ------------------------------------------
#Data frames are tabular data objects. Unlike a matrix in data frame each column 
#can contain different modes of data. The first column can be numeric while 
#the second column can be character and third column can be logical. 
#It is a list of vectors of equal length.

#Data Frames are created using the data.frame() function.

# Create the data frame.
BMI <- 	data.frame(
  gender = c("Male", "Male","Female"), 
  height = c(152, 171.5, 165), 
  weight = c(81,93, 78),
  Age =c(42,38,26)
)
print(BMI)

#Factors in DataFrames
# Create the vectors for data frame.
height <- c(132,151,162,139,166,147,122)
weight <- c(48,49,66,53,67,52,40)
gender <- c("male","male","female","female","male","female","male")

# Create the data frame.
input_data <- data.frame(height,weight,gender)
print(input_data)

# Test if the gender column is a factor.
print(is.factor(input_data$gender))

# Print the gender column so see the levels.
print(input_data$gender)

#----Characteristics of Data Frame
#Following are the characteristics of a data frame.
#The column names should be non-empty.
#The row names should be unique.
#The data stored in a data frame can be of numeric, factor or character type.
#Each column should contain same number of data items.

?data.frame()
# Create the data frame.
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11","2015-03-27"))
  #stringsAsFactors=FALSE
)
# Print the data frame.			
print(emp.data) 

#-----------Get the Structure of the Data Frame
#The structure of the data frame can be seen by using str() function.
?data.frame()
# Create the data frame.
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11","2015-03-27")),
  stringsAsFactors=FALSE
  
)
# Get the structure of the data frame.
str(emp.data)
print(class(emp.data))


#---------------Summary of Data in data frame
#The statistical summary and nature of the data can be obtained by applying summary() function.

# Create the data frame.
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11","2015-03-27")),
  stringsAsFactors=FALSE
)
# Print the summary.
print(summary(emp.data))

#-------------Extract Data from data frame
#Extract specific column from a data frame using column name.
# Create the data frame.
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11","2015-03-27")),
  stringsAsFactors=FALSE
)
# Extract Specific columns.
result <- data.frame(emp.data$emp_name,emp.data$salary)
print(result)

#Extract first two rows and all columns
# Create the data frame.
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11","2015-03-27")),
  stringsAsFactors=FALSE
)
# Extract first two rows.
result <- emp.data[1:2,]
print(result)


#Extract 3rd and 5th row with 2nd and 4th column
# Create the data frame.
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11","2015-03-27")),
  stringsAsFactors=FALSE
)

# Extract 3rd and 5th row with 2nd and 4th column.
result <- emp.data[c(3:5),c(2:4)]
print(result)

emp.data[3,1]=3
print(emp.data)

#Expand data frame
#A data frame can be expanded by adding columns and rows.

#Add column
#Just add the column vector using a new column name.

# Create the data frame.
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11","2015-03-27")),
  stringsAsFactors=FALSE
)

# Add the "dept" coulmn.
emp.data$dept <- c("IT","Operations","IT","HR","Finance")
v <- emp.data
print(v)

#Removing a column from the data Frame
emp.data$salary=NULL

#Deleting a Data Frame
rm(emp.data)
print(emp.data)


#------------------------------Operators-------------------------------------------

#Colon operator. It creates the series of numbers in sequence for a vector.
v <- 1:5
print(v)

#%in%:	This operator is used to identify if an element belongs to a vector.
v1 <- 8
v2 <- 12
t <- 1:10
print(v1 %in% t) 
print(v2 %in% t) 


#%*%	This operator is used to multiply a matrix with its transpose.	
M = matrix( c(2,6,5,1,10,4), nrow=2,ncol=3,byrow = TRUE)
t = M %*% t(M)
print(t)


?data.table()
