#Let's start with a simple dotchart graphing the autos data: 
# Read values from tab-delimited autos.dat
autos_data <- read.table("autos.dat", header=T, sep="\t")

# Create a dotchart for autos
dotchart(t(autos_data))

#------------------------------------------------------
#Let's make the dotchart a little more colorful: 
# Read values from tab-delimited autos.dat
autos_data <- read.table("autos.dat", header=T, sep="\t")

# Create a colored dotchart for autos with smaller labels
dotchart(t(autos_data), color=c("red","blue","darkgreen"),
   main="Dotchart for Autos", cex=0.8)

#------------------------------------------------------
#This example shows all 25 symbols that you can use to
#produce points in your graphs: 
  # Make an empty chart
  plot(1, 1, xlim=c(1,5.5), ylim=c(0,7), type="n", ann=FALSE)

# Plot digits 0-4 with increasing size and color
text(1:5, rep(6,5), labels=c(0:4), cex=1:5, col=1:5)

# Plot symbols 0-4 with increasing size and color
points(1:5, rep(5,5), cex=1:5, col=1:5, pch=0:4)
text((1:5)+0.4, rep(5,5), cex=0.6, (0:4))

# Plot symbols 5-9 with labels
points(1:5, rep(4,5), cex=2, pch=(5:9))
text((1:5)+0.4, rep(4,5), cex=0.6, (5:9))

# Plot symbols 10-14 with labels
points(1:5, rep(3,5), cex=2, pch=(10:14))
text((1:5)+0.4, rep(3,5), cex=0.6, (10:14))

# Plot symbols 15-19 with labels
points(1:5, rep(2,5), cex=2, pch=(15:19))
text((1:5)+0.4, rep(2,5), cex=0.6, (15:19))

# Plot symbols 20-25 with labels
points((1:6)*0.8+0.2, rep(1,6), cex=2, pch=(20:25))
text((1:6)*0.8+0.5, rep(1,6), cex=0.6, (20:25))

#------------------------------------------------------
#R has four in built functions to generate normal distribution. 
#They are described below.

#dnorm(x, mean, sd)
#pnorm(x, mean, sd)
#qnorm(p, mean, sd)
#rnorm(n, mean, sd)
#Following is the description of the parameters used
#in above functions −

#x is a vector of numbers.

#p is a vector of probabilities.

#n is number of observations(sample size).

#mean is the mean value of the sample data. 
#It's default value is zero.

#sd is the standard deviation. It's default value is 1.

#dnorm()
#This function gives height of the probability distribution at 
#each point for a given mean and standard deviation.

x <- seq(-10, 10, by = .1)

# Choose the mean as 2.5 and standard deviation as 0.5.
y <- dnorm(x, mean = 2.5, sd = 0.5)

# Give the chart file a name.
png(file = "dnorm.png")

plot(x,y)

# Save the file.
dev.off()
#------------------------------------------------------

#pnorm()
#This function gives the probability of a normally distributed random number to be less that the value of a given number. It is also called "Cumulative Distribution Function".


# Create a sequence of numbers between -10 and 10 incrementing by 0.2.
x <- seq(-10,10,by = .2)

# Choose the mean as 2.5 and standard deviation as 2. 
y <- pnorm(x, mean = 2.5, sd = 2)

# Give the chart file a name.
png(file = "pnorm.png")

# Plot the graph.
plot(x,y)

# Save the file.
dev.off()


#-------------------------

#qnorm()
#This function takes the probability value and gives a number whose cumulative value matches the probability value.

# Create a sequence of probability values incrementing by 0.02.
x <- seq(0, 1, by = 0.02)

# Choose the mean as 2 and standard deviation as 3.
y <- qnorm(x, mean = 2, sd = 1)

# Give the chart file a name.
png(file = "qnorm.png")

# Plot the graph.
plot(x,y)

# Save the file.
dev.off()


#-=-=-=-=-=-
 
#rnorm()
#This function is used to generate random numbers whose distribution is normal. It takes the sample size as input and generates that many random numbers. We draw a histogram to show the distribution of the generated numbers.

# Create a sample of 50 numbers which are normally distributed.
y <- rnorm(50)

# Give the chart file a name.
png(file = "rnorm.png")

# Plot the histogram for this sample.
hist(y, main = "Normal DIstribution")

# Save the file.
dev.off() 

#===== extra

library(descr)
x = c(sample(10:20, 44, TRUE))
freq(x, plot = FALSE)