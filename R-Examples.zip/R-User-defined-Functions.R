fn.add <- function(a,b){
  return(a+b)
}

fn.diff <- function(a,b){
  return(a-b)
}

fn.product <- function(a,b){
  return(a*b)
}

fn.arithmetic_opeartion <- function() {
  print(fn.add(3,4))
  print(fn.diff(3,4))
}

fn.arithmetic_opeartion()

#----------- Function with Argument ------------------------

# Create a function to print squares of numbers in sequence.
new.function <- function(a) {
  for(i in 1:a) {
    b <- i^2
    print(b)
  }
}

# Call the function new.function supplying 6 as an argument.
new.function(6)

#----------- Function without Argument ------------------------
# Create a function without an argument.
new.function <- function() {
  for(i in 1:5) {
    print(i^2)
  }
}	

# Call the function without supplying an argument.
new.function()

#------Calling a Function with Argument Values (by position and by name)--------
# Create a function with arguments.
new.function <- function(a,b,c) {
  result <- a*b+c
  print(result)
}

# Call the function by position of arguments.
new.function(5,3,11)

# Call the function by names of the arguments.
new.function(a=11,b=5,c=3)
new.function(b=5,a=11,c=3)
#--------------Calling a Function with Default Argument----------------------
# Create a function with arguments.
new.function <- function(a = 3,b =6) {
  result <- a*b
  print(result)
}

# Call the function without giving any argument.
new.function()

# Call the function with giving new values of the argument.
new.function(9,5)

#Lazy Evaluation of Function:Arguments to functions are evaluated lazily, 
#which means so they are evaluated only when needed by the function body.

