#he readline function

#readline() lets the user enter a one-line string at the terminal. 
#The prompt argument is printed in front of the user input. 
#It usually ends on ": ".
#----------------- User input -------------------------


#The as.integer function: gets an integer out of the string.
readinteger <- function()
{ 
  n <- readline(prompt="Enter an integer: ")
  n <- as.integer(n)
  if (is.na(n)){
    n <- readinteger()
  }
  return(n)
}


#preventing a warning message in the above
readinteger <- function()
{ 
  n <- readline(prompt="Enter an integer: ")
  if(!grepl("^[0-9]+$",n))
  {
    return(readinteger())
  }
  
  return(as.integer(n))
}

print(readinteger)