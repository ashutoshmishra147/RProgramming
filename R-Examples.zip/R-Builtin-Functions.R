#------------------------Numeric Functions ---------------------------------

# Create a sequence of numbers from 32 to 44.
print(seq(32,44))

# Find mean of numbers from 25 to 82.
print(mean(25:82))

# Find sum of numbers frm 41 to 68.
print(sum(41:68))

#------------------------String Functions ---------------------------------

#paste() function
#Many strings in R are combined using the paste() function. 
#It can take any number of arguments to be combined together.
a <- "Hello"
b <- 'How'
c <- "are you? "

print(paste(a,b,c))
print(paste(a,b,c, sep = "-"))
print(paste(a,b,c, sep = "", collapse = ""))
#collapse is used to eliminate the space in between two strings. 
#But not the space within two words of one string.

#format() function :Numbers and strings can be formatted to a specific style

# Total number of digits displayed. Last digit rounded off.
result <- format(23.123456789, digits = 9)
print(result)

# Display numbers in scientific notation.
result <- format(c(6, 13.14521), scientific = TRUE)
print(result)

# The minimum number of digits to the right of the decimal point.
result <- format(23.47, nsmall = 5)
print(result)

# Format treats everything as a string.
result <- format(6)
print(result)

# Numbers are padded with blank in the beginning for width.
result <- format(13.7, width = 6)
print(result)

# Left justify strings.
result <- format("Hello",width = 8, justify = "l")
print(result)

# Justfy string with center.
result <- format("Hello",width = 8, justify = "c")
print(result)

#nchar() function :Counts the number of characters including spaces in a string.
result <- nchar("Count the number of characters")
print(result)

#toupper() & tolower() functions :Change the case of characters of a string.
# Changing to Upper case.
result <- toupper("Changing To Upper")
print(result)

# Changing to lower case.
result <- tolower("Changing To Lower")
print(result)

#substring() function: Extract parts of the String
# Extract characters from 5th to 7th position.
result <- substring("Extract", 5, 7)
print(result)


