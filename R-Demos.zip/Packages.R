#Get library locations containing R packages
.libPaths()

#Get the list of all the packages installed
library()

#Install a New Package
#There are two ways to add new R packages. 
#  1.) Directly from the CRAN directory and 
#  2.) Downloading the package to your local system and installing it manually.

# 1.Install directly from CRAN
install.packages("XML")

# 2. Install package manually
#Go to the link R Packages to download the package needed. 
#Save the package as a .zip file in a suitable location in the local system.

#Syntax: install.packages(file_name_with_path, repos = NULL, type = "source")

# Install the package named "XML"
install.packages("E:/XML_3.98-1.3.zip", repos = NULL, type = "source")

# Load Package to Library
# Before a package can be used in the code, it must be loaded to the current R environment. 





