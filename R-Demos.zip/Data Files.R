#-------------------Getting and Setting the Working Directory-----------
#getwd() and setwd()

# Get and print current working directory.
print(getwd())

# Set current working directory.
setwd("D:\\Notes\\Analytics\\R\\Demos")

# Get and print current working directory.
print(getwd())
#----------------- R-Data ------------------------------------
#the default installation of R comes with several data sets.Use data() to get it
data()

#To get a printout of the entire data set if you type the name of the 
#data set into the console
Orange
Titanic

#------------------------Importing TXT files-------------

#If you have a .txt or a tab-delimited text file, you can easily import 
#it with the basic R function read.table()

df <- read.table("D:\\Notes\\Analytics\\R\\Demos\\SampleText.txt",header = FALSE)

#----------------------------Reading a Data File : CSV -----------------------

#CSV File
data <- read.csv("D:\\Notes\\Analytics\\R\\Demos\\input.csv")
print(data)

#If you are not sure what columns are contained in the variable you can use the names command:
names(data)


#The read.csv function assumes that your file has a header row, 
#so row 1 is the name of each column. If that's not the case, you can add 
#header=FALSE to the command:

#Analyzing the CSV File
print(is.data.frame(data))
print(ncol(data))
print(nrow(data))

# Get the max salary from data frame.
sal <- max(data$salary)
print(sal)

# Get the person detail having max salary.
retval <- subset(data, salary == max(salary))
print(retval)

# Get details of all people working in IT Department
retval <- subset( data, dept == "IT")
print(retval)

# Get details of all people working in IT Department whose salary is greater than 600
info <- subset(data, salary > 600 & dept == "IT")
print(info)

#Get details of people who joined on or after 2014
retval <- subset(data, as.Date(start_date) > as.Date("2014-01-01"))
print(retval)

# Write filtered data into a new file.
retval <- subset(data, as.Date(start_date) > as.Date("2014-01-01"))
write.csv(retval,"D:\\Notes\\Analytics\\R\\Demos\\output.csv")
newdata <- read.csv("D:\\Notes\\Analytics\\R\\Demos\\output.csv")
print(newdata)

# Write filtered data into a new file:- dropping additional parameters 
write.csv(retval,"output.csv", row.names = FALSE)
newdata <- read.csv("output.csv")
print(newdata)

# Sort data by one column
sort_data <- stulevel[order(stulevel$ability) , ]


d = read.table("D:\\Notes\\Analytics\\R\\Demos\\simple.csv", head=TRUE,sep=",")
print(d)
summary(d)

#----------------------------Reading a Data File : Excel -----------------------
#R can read directly from these files using some excel specific packages. 
#Few such packages are - XLConnect, xlsx, gdata etc.

install.packages("xlsx")

#-------Verify and Load the "xlsx" Package-----------

# Verify the package is installed.
any(grepl("xlsx",installed.packages()))

# Load the library into R workspace.
library("xlsx")

