
#------------------------------ Data Reshaping --------------------------
#Data Reshaping in R is about changing the way data is organized into rows and columns.
#R has many functions to split, merge and change the rows to columns and vice-versa in a data frame.

#------------------------------ Joining Columns and Rows in Data Frame --------------------------
#cbind()function: We can join multiple vectors to create a data frame. 
#rbind() function: we can merge two data frames.
# Create vector objects.
city <- c("Tampa","Seattle","Hartford","Denver")
state <- c("FL","WA","CT","CO")
zipcode <- c(33602,98104,06161,80294)

# Combine above three vectors into one data frame.
addresses <- data.frame(cbind(city,state,zipcode))

# Print a header.
cat("# # # # The First data frame\n") 

# Print the data frame.
print(addresses)
print(class(addresses))

# Create another data frame with similar columns
new.address <- data.frame(
  city = c("Lowry","Charlotte"),
  state = c("CO","FL"),
  zipcode = c("80230","33949"),
  stringsAsFactors = FALSE
)

# Print a header.
cat("# # # The Second data frame\n") 

# Print the data frame.
print(new.address)

# Combine rows form both the data frames.
all.addresses <- rbind(addresses,new.address)

# Print a header.
cat("# # # The combined data frame\n") 

# Print the result.
print(all.addresses)

one <- data.frame(
  city = c("Lowry","Charlotte"),
  state = c("CO","FL")
)

two <- data.frame(
  zipcode = c("80230","33949"),
  stringsAsFactors = FALSE
)

three=data.frame(cbind(one,two))
print(three)

four <- data.frame(
  city = c("Lowry","Charlotte"),
  state = c("N_CO","N_FL"),
  zipcode = c("N_80230","N_33949"),
  stringsAsFactors = FALSE
)

five=data.frame(rbind(three,four))
print(five)

six <- data.frame(
  city = c("N_Lowry","N_Charlotte"),
  state1 = c("N_CO","N_FL"),
  zipcode123 = c("N_80230","N_33949"),
  stringsAsFactors = FALSE
)

seven=data.frame(rbind(five,six))
print(seven)


eight <- data.frame(
  city = c("X","N_Charlotte"),
  state1 = c("X","N_FL"),
  zipcode123 = c("X","N_33949"),
  stringsAsFactors = FALSE
)

nine <- data.frame(rbind(one,eight))
print(nine)

seven=data.frame(rbind(seven,eight))
print(eight)
#----------------------------- Merging Data Frames----------------------------------
#merge() function: merge two data frames.The data frames must have same column names on which the merging happens.

#consider the data sets about Diabetes in Pima Indian Women available in the library names "MASS". 
#we merge the two data sets based on the values of blood pressure("bp") and body mass index("bmi"). 
#On choosing these two columns for merging, the records where values of these two variables match 
#in both data sets are combined together to form a single data frame.


library(MASS)
merged.Pima <- merge(x = Pima.te, y = Pima.tr,
                     by.x = c("bp", "bmi"),
                     by.y = c("bp", "bmi")
)
print(merged.Pima)
nrow(merged.Pima)


#----------------------Melting and Casting------------------------------------------
#One of the most interesting aspects of R programming is about changing the shape of the data 
#in multiple steps to get a desired shape. The functions used to do this are called melt() and cast().

#We consider the dataset called ships present in the library called "MASS".

library(MASS)
print(ships)

#melt the data to organize it, converting all columns other than type and year into multiple rows.

molten.ships <- melt(ships, id = c("type","year"))
print(molten.ships)







